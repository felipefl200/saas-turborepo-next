import { SignInForm } from './signin-form'

export default function SignInPage() {
  return <SignInForm />
}
