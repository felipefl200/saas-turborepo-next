'use client'

import Header from '@/components/header'
import { useSelectedLayoutSegments } from 'next/navigation'
import AuthLayout from './layout'

export default function Template({ children }: { children: React.ReactNode }) {
  const segments = useSelectedLayoutSegments()
  const isSheet = segments.includes('@sheet')

  return (
    <AuthLayout>
      <div className="space-y-4 py-4">
        {!isSheet && <Header />}
        {children}
      </div>
    </AuthLayout>
  )
}
